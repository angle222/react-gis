// const { createProxyMiddleware } = require("http-proxy-middleware");
// module.exports = function(app) {
//   app.use(
//     createProxyMiddleware("/crawler", {
//     //   target: "http://m.kugou.com?json=true",
//       target: "http://192.168.0.187:8082/",
//       changeOrigin: true
//     })
//   );
// };

export const $_menuData = [
  {
    name: "首页",
    icon: "el-icon-s-home",
    route: "home"
  },
  {
    name: "地图服务",
    icon: "el-icon-s-operation",
    route: "mapservices",
    childs: []
  },
  {
    name: "系统设置",
    route: "settings",
    icon: "el-icon-setting",
    childs: []
  }
];

/**
 * created by Allan on 06/24/2018
 */
module.exports = {
  success: true,
  result: {
    "name": "《Sugar-Maroon》",
    "url":
      "http://other.web.rh01.sycdn.kuwo.cn/resource/n1/40/36/1406203899.mp3"
  }
};

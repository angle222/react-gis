/**
 * created by Allan on 06/24/2018
 */
// module.exports = {
//   errorCode: "0", //非0表示出错
//   errorMsg: "success"
// };
